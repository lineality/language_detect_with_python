import re

def split_into_sentences(text):
    # List of common abbreviations to avoid splitting on
    abbreviations = r'(Mr|Dr|Mrs|Ms|Jr|Sr|St|Ave|Blvd|Rd|Mt|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|[A-Z]\.)'

    # Replace abbreviations with a placeholder to prevent splitting on them
    placeholder = "ABBREVIATIONPLACEHOLDER"
    text = re.sub(r'(' + abbreviations + r')(\.|\s+)', r'\1' + placeholder, text)

    # Split the text into sentences
    sentences = re.split(r'(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?)\s', text)

    # Replace the placeholder back with a period
    sentences = [sentence.replace(placeholder, ".") for sentence in sentences]

    return sentences

def process_wiki_article(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        text = file.read()

    sentences = split_into_sentences(text)
    return sentences

def save_sentences_to_file(sentences, output_file_path):
    with open(output_file_path, 'w', encoding='utf-8') as file:
        for sentence in sentences:
            file.write(sentence + '\n')

# use
input_file_path = 'text_doc.txt'
output_file_path = 'sentences_list.txt'

sentences = process_wiki_article(input_file_path)
save_sentences_to_file(sentences, output_file_path)

print(f"Processed {len(sentences)} sentences and saved to {output_file_path}")


# clean

def remove_short_sentences(input_file_path, output_file_path, min_length=60):
    with open(input_file_path, 'r', encoding='utf-8') as file:
        sentences = file.readlines()

    # Filter out sentences shorter than min_length characters
    filtered_sentences = [sentence for sentence in sentences if len(sentence.strip()) >= min_length]

    with open(output_file_path, 'w', encoding='utf-8') as file:
        for sentence in filtered_sentences:
            file.write(sentence)

    return filtered_sentences

# Example usage
input_file_path = 'sentences_list.txt'
output_file_path = 'clean_sentences_list.txt'

filtered_sentences = remove_short_sentences(input_file_path, output_file_path)

print(f"Filtered {len(filtered_sentences)} sentences and saved to {output_file_path}")


