import statistics

# Open the file
with open('clean_sentences_list.txt', 'r') as file:
    sentences = file.readlines()

# Calculate word length and character length for each sentence
word_lengths = [len(sentence.split()) for sentence in sentences]
char_lengths = [len(sentence) for sentence in sentences]

# Calculate mean, median, and mode
mean_word_length = statistics.mean(word_lengths)
median_word_length = statistics.median(word_lengths)
mode_word_length = statistics.mode(word_lengths)

mean_char_length = statistics.mean(char_lengths)
median_char_length = statistics.median(char_lengths)
mode_char_length = statistics.mode(char_lengths)

# Calculate quartiles
q25_word_length = statistics.quantiles(word_lengths, n=4)[0]
q75_word_length = statistics.quantiles(word_lengths, n=4)[2]

q25_char_length = statistics.quantiles(char_lengths, n=4)[0]
q75_char_length = statistics.quantiles(char_lengths, n=4)[2]

# Print the results
print("\nper sentence\n")

print('word:')
print(f'Mean words: {mean_word_length}')
print(f'Median words: {median_word_length}')
print(f'Mode words: {mode_word_length}')
print(f'25th Percentile words: {q25_word_length}')
print(f'75th Percentile words: {q75_word_length}\n')

print('char')
print(f'Mean characters: {mean_char_length}')
print(f'Median characters: {median_char_length}')
print(f'Mode characters: {mode_char_length}')
print(f'25th Percentile characters: {q25_char_length}')
print(f'75th Percentile characters: {q75_char_length}')

