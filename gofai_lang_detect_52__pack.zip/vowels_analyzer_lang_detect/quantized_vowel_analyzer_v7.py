"""
# Vowel-Length Ratio Text Analyzer

A minimal empirical, focused, approach,
looking at each empirical selection of possible words
from a +200k word wikipedia corpus

LEN_TO_N_VOWELS = {
    # # {word_length: [possible vowel quantities]}
    2:  [1],
    
    3:  [1, 2, 3],
    4:  [1, 2, 3],
    5:  [1, 2, 3],
    
    6:  [1, 2, 3, 4],
    7:  [1, 2, 3, 4, 5],
    
    8:     [2, 3, 4, 5],
    9:     [2, 3, 4, 5, 6],
    10:    [2, 3, 4, 5, 6],
    
    11:       [3, 4, 5, 6],
    
    12:       [3, 4, 5, 6, 7],
    13:       [3, 4, 5, 6, 7],
    
    14:          [4, 5, 6, 7],
    
    15:             [5, 6, 7, 8],
    
    16:                [6, 7],

    17:                [6, 7, 8],
    18:                [6, 7, 8],
}
"""
import re


# how many words are required to print the number at all
# e.g. 2 obscure words do not represent a meaningful class of words
MIN_WORD_COUNT_THRESHOLD = 5


def check_and_print_all_vowels(strings):
    ok_characters = ['a','e','i','o','u','y']
    for string in strings:
        if all(char in ok_characters for char in string):
            print(string)


def len_n_vowel_sublist(strings, N):
    """
    input list of words
    output sublist with n vowels
    """
    ok_characters = ['a','e','i','o','u','y']
    result = []
    for string in strings:
        if sum(char in ok_characters for char in string) == N:
            result.append(string)
            
    result = set(result)
    result = list(result)
    
    # if result:
    #     print(f"N={N}")
    #     print(f"count->{len(result)}\n")
        
    if len(result) >= MIN_WORD_COUNT_THRESHOLD:
        print(f"N={N}")
        print(f"count->{len(result)}\n")
    return result


def n_vowel_sublist(strings, N):
    """
    input list of words
    output sublist with n vowels
    """
    ok_characters = ['a','e','i','o','u','y']
    result = []
    for string in strings:
        if sum(char in ok_characters for char in string) == N:
            result.append(string)
    result = set(result)
    result = list(result) 
    
    if result:
        print(f"words with {N} vowels -> ")
        print(result,'\n')
    return result


def word_inspectionize(length_of_words, number_of_vowels, list_of_corpus_words, blurb=None):
    print(f"\n\nWord For: Word-Length {length_of_words}, and vowel number {number_of_vowels}:")
    
    if blurb:
        print(blurb)
    
    # length of words
    result = [item for item in list_of_corpus_words if len(item) == length_of_words]
    # number of vowels
    n_vowel_sublist(result, number_of_vowels)


def report_word_length_counts(words):
    """
    Calculate the number and percentage of string length counts for each word in a given input list of words.

    Args:
    words (list): A list of words to analyze.

    Returns:
    None

    Prints:
    A report for each word length in the dictionary, showing its count and the percentage of the total number of words that it represents.
    """
    # Define the total number of words in the list
    total_words = len(words)

    # Create a dictionary to store the count of each word length
    word_length_counts = {}

    # Iterate over each word in the list of words
    for word in words:
        # Calculate the length of the word
        word_length = len(word)

        # If the word length is already in the dictionary, increment its count
        if word_length in word_length_counts:
            word_length_counts[word_length] += 1
        # If the word length is not in the dictionary, add it with a count of 1
        else:
            word_length_counts[word_length] = 1

    # Sort the dictionary by word length
    sorted_word_length_counts = dict(sorted(word_length_counts.items()))

    # Print the report
    for word_length, count in sorted_word_length_counts.items():
        percent = round((count / total_words) * 100, 4)
        print(f"Word Length: {word_length}, Count: {count}, Percent: {percent}%")

# # Test the function
# report_word_length_counts(["Hello", "World", "This", "is", "a", "test"])


def analyze_vowels_empirical(text: str) -> dict:
    """
    Empirically show how many words exist
    - within a corpus text
    - per word length
    - per number of vowels
  
    """
    
    VOWELS = set('aeiouyAEIOUY')  # Including y/Y as potential vowels
    
    # Clean and tokenize text
    list_of_corpus_words = re.findall(r'\b[a-zA-Z]+\b', text.lower())
    
    print(f"how many list_of_corpus_words, len(): -> {len(list_of_corpus_words)}")

    # Test the function
    print("\nReport on word lengths in the corpus:")
    report_word_length_counts(list_of_corpus_words)



    #################################
    # For words 0-20 in length
    # Show number of vowel cases > 5
    #################################

    for this_word_length in range(0,20):

        print(f"\n\nFor Word Length {this_word_length}:")
        result = [item for item in list_of_corpus_words if len(item) == this_word_length]

        for this_vowel_number in range(0,20):
            len_n_vowel_sublist(result, this_vowel_number)


    #################################
    # Show actaul words for one case
    #################################
    print("Inspected edge-cases and small groupingses:")
    
    length_of_words = 2
    number_of_vowels = 0
    blurb = "moderate group size BUT not words, edge-case"
    word_inspectionize(length_of_words, number_of_vowels, list_of_corpus_words, blurb)

    length_of_words = 3
    number_of_vowels = 0
    blurb = "moderate group size BUT not words, edge-case"
    word_inspectionize(length_of_words, number_of_vowels, list_of_corpus_words, blurb)
    
    length_of_words = 3
    number_of_vowels = 3
    blurb = "..."
    word_inspectionize(length_of_words, number_of_vowels, list_of_corpus_words, blurb)
    
    length_of_words = 4
    number_of_vowels = 0
    blurb = "~small group size, not words"
    word_inspectionize(length_of_words, number_of_vowels, list_of_corpus_words, blurb)
    
    length_of_words = 5
    number_of_vowels = 0
    blurb = "can be ignored"
    word_inspectionize(length_of_words, number_of_vowels, list_of_corpus_words, blurb)
    
    length_of_words = 5
    number_of_vowels = 4
    blurb = "can be ignored"
    word_inspectionize(length_of_words, number_of_vowels, list_of_corpus_words, blurb)

    length_of_words = 7
    number_of_vowels = 1
    blurb = "include: small but real, edge case"
    word_inspectionize(length_of_words, number_of_vowels, list_of_corpus_words, blurb)
    
    length_of_words = 7
    number_of_vowels = 5
    blurb = "note: small group BUT real common words"
    word_inspectionize(length_of_words, number_of_vowels, list_of_corpus_words, blurb)
    
    length_of_words = 9
    number_of_vowels = 6
    blurb = "can be ignored"
    word_inspectionize(length_of_words, number_of_vowels, list_of_corpus_words, blurb)
    
    length_of_words = 10
    number_of_vowels = 2
    blurb = "include"
    word_inspectionize(length_of_words, number_of_vowels, list_of_corpus_words, blurb)
    
    print("\nNote: Over len ~12 words are few, safe rule: include any")
    
    length_of_words = 12
    number_of_vowels = 7
    blurb = "note: small group BUT real common words"
    word_inspectionize(length_of_words, number_of_vowels, list_of_corpus_words, blurb)    
    
    length_of_words = 13
    number_of_vowels = 3
    blurb = "include"
    word_inspectionize(length_of_words, number_of_vowels, list_of_corpus_words, blurb) 

    length_of_words = 16
    number_of_vowels = 5
    blurb = "..."
    word_inspectionize(length_of_words, number_of_vowels, list_of_corpus_words, blurb)    


# Print Report
if __name__ == "__main__":
    # Test text handling
    default_test_text = """
    hello world
    """

    print(f"""
    Welcome the character-verbs analyz-a-tron-5000
    # How many words are required to print the number at all
    # e.g. 2 obscure words do not represent a meaningful class of words
    MIN_WORD_COUNT_THRESHOLD = {MIN_WORD_COUNT_THRESHOLD}
    
    The following word-len to word-count by vowel-number results
    are your targets:
    if for a string X, of len(A), if the vowel count is not in list(B),
    then it is unlikely that string X is a word -> label word/not-word

    This is empirical target selection: 
    there is no 'one linear equation of the one pure truth'
    that absolutely defines what these target value-lists are for one
    language or for all languages.
    
    Note: see below for not-'words' that are len(2) vowels(0)
    This is an edge-case of many non-words.
    
    Goal: Map empirical data into a tool lookup such as:
    
    LEN_TO_N_VOWELS_DICT = (
    # # word_length: [possible vowel quantities]
    2:  [1],
    
    3:  [1, 2, 3],
    4:  [1, 2, 3],
    5:  [1, 2, 3],
    
    6:  [1, 2, 3, 4],
    7:  [1, 2, 3, 4, 5],
    
    8:     [2, 3, 4, 5],
    9:     [2, 3, 4, 5, 6],
    10:    [2, 3, 4, 5, 6],
    
    11:       [3, 4, 5, 6],
    
    12:       [3, 4, 5, 6, 7],
    13:       [3, 4, 5, 6, 7],
    
    14:          [4, 5, 6, 7],
    
    15:             [5, 6, 7, 8],
    
    16:                [6, 7],

    17:                [6, 7, 8],
    18:                [6, 7, 8],
    )
    """) 

    try:
        with open('wikipedia_samples_text_doc.txt', 'r', encoding='utf-8') as file:
            test_text = file.read()
            if not test_text.strip():
                raise ValueError("File is empty")
    except (FileNotFoundError, ValueError) as e:
        print(f"Using default test text. Error: {str(e)}")
        test_text = default_test_text
    except Exception as e:
        print(f"Unexpected error: {str(e)}")
        test_text = default_test_text

    # Analyze text
    analyze_vowels_empirical(test_text)
    
    
"""sample output
$ python3 analyzer_slim_v5.py 

    Welcome the character-verbs analyz-a-tron-5000
    # How many words are required to print the number at all
    # e.g. 2 obscure words do not represent a meaningful class of words
    MIN_WORD_COUNT_THRESHOLD = 5
    
    The following word-len to word-count by vowel-number results
    are your targets:
    if for a string X, of len(A), if the vowel count is not in list(B),
    then it is unlikely that string X is a word -> label word/not-word

    This is empirical target selection: 
    there is no 'one linear equation of the one pure truth'
    that absolutely defines what these target value-lists are for one
    language or for all languages.
    
    Note: see below for not-'words' that are len(2) vowels(0)
    This is an edge-case of many non-words.
    
    

    
    
how many list_of_corpus_words, len(): -> 215784

Report on word lengths in the corpus:
Word Length: 1, Count: 7581, Percent: 3.5132%
Word Length: 2, Count: 30051, Percent: 13.9264%
Word Length: 3, Count: 35375, Percent: 16.3937%
Word Length: 4, Count: 26142, Percent: 12.1149%
Word Length: 5, Count: 24367, Percent: 11.2923%
Word Length: 6, Count: 21181, Percent: 9.8158%
Word Length: 7, Count: 21925, Percent: 10.1606%
Word Length: 8, Count: 17130, Percent: 7.9385%
Word Length: 9, Count: 13301, Percent: 6.164%
Word Length: 10, Count: 8232, Percent: 3.8149%
Word Length: 11, Count: 4519, Percent: 2.0942%
Word Length: 12, Count: 2607, Percent: 1.2082%
Word Length: 13, Count: 2296, Percent: 1.064%
Word Length: 14, Count: 623, Percent: 0.2887%
Word Length: 15, Count: 237, Percent: 0.1098%
Word Length: 16, Count: 94, Percent: 0.0436%
Word Length: 17, Count: 53, Percent: 0.0246%
Word Length: 18, Count: 26, Percent: 0.012%
Word Length: 19, Count: 15, Percent: 0.007%
Word Length: 20, Count: 9, Percent: 0.0042%
Word Length: 21, Count: 7, Percent: 0.0032%
Word Length: 22, Count: 1, Percent: 0.0005%
Word Length: 23, Count: 2, Percent: 0.0009%
Word Length: 25, Count: 1, Percent: 0.0005%
Word Length: 26, Count: 2, Percent: 0.0009%
Word Length: 29, Count: 1, Percent: 0.0005%
Word Length: 30, Count: 1, Percent: 0.0005%
Word Length: 32, Count: 2, Percent: 0.0009%
Word Length: 33, Count: 1, Percent: 0.0005%
Word Length: 37, Count: 1, Percent: 0.0005%
Word Length: 49, Count: 1, Percent: 0.0005%


For Word Length 0:


For Word Length 1:
N=0
count->19

N=1
count->6



For Word Length 2:
N=0
count->84

N=1
count->103

N=2
count->11



For Word Length 3:
N=0
count->73

N=1
count->401

N=2
count->159

N=3
count->6



For Word Length 4:
N=0
count->24

N=1
count->589

N=2
count->754

N=3
count->54



For Word Length 5:
N=0
count->5

N=1
count->395

N=2
count->1414

N=3
count->352

N=4
count->7



For Word Length 6:
N=1
count->100

N=2
count->1555

N=3
count->1051

N=4
count->94



For Word Length 7:
N=1
count->15

N=2
count->1077

N=3
count->1507

N=4
count->354

N=5
count->10



For Word Length 8:
N=2
count->437

N=3
count->1305

N=4
count->790

N=5
count->53



For Word Length 9:
N=2
count->132

N=3
count->874

N=4
count->990

N=5
count->201

N=6
count->6



For Word Length 10:
N=2
count->25

N=3
count->391

N=4
count->781

N=5
count->367

N=6
count->23



For Word Length 11:
N=3
count->104

N=4
count->442

N=5
count->428

N=6
count->89



For Word Length 12:
N=3
count->26

N=4
count->146

N=5
count->337

N=6
count->127

N=7
count->8



For Word Length 13:
N=3
count->5

N=4
count->49

N=5
count->150

N=6
count->139

N=7
count->20



For Word Length 14:
N=4
count->16

N=5
count->57

N=6
count->78

N=7
count->37



For Word Length 15:
N=5
count->22

N=6
count->46

N=7
count->32

N=8
count->5



For Word Length 16:
N=6
count->19

N=7
count->18



For Word Length 17:
N=6
count->5

N=7
count->12

N=8
count->9



For Word Length 18:
N=6
count->5

N=7
count->6

N=8
count->7



For Word Length 19:
Inspected edge-cases and small groupingses:


Word For: Word-Length 2, and vowel number 0:
moderate group size BUT not words, edge-case
words with 0 vowels -> 
['vz', 'bc', 'jl', 'tj', 'vs', 'tx', 'lr', 'pj', 'cc', 'cm', 'kt', 'rg', 'kg', 'll', 'fr', 'ww', 'cb', 'ns', 'jv', 'pr', 'mv', 'tv', 'dx', 'vp', 'ch', 'js', 'rs', 'sv', 'nz', 'rr', 'pl', 'fl', 'kb', 'gb', 'qc', 'mk', 'jr', 'vm', 'kw', 'pp', 'nm', 'rn', 'rj', 'mm', 'ct', 'md', 'sh', 'tr', 'jp', 'dj', 'fn', 'gt', 'wm', 'ft', 'dc', 'nc', 'mn', 'rm', 'nw', 'dr', 'ds', 'bl', 'sc', 'lt', 'jj', 'km', 'xv', 'dk', 'pk', 'mr', 'sm', 'ss', 'nj', 'nd', 'nl', 'st', 'ms', 'hm', 'gr', 'br', 'xx', 'sj', 'tm', 'pg'] 



Word For: Word-Length 3, and vowel number 0:
moderate group size BUT not words, edge-case
words with 0 vowels -> 
['dsv', 'cbs', 'pbs', 'dcs', 'jtr', 'mcb', 'ssn', 'phd', 'crc', 'smn', 'llb', 'cgt', 'mcs', 'vsp', 'jpl', 'rtd', 'vlf', 'grt', 'rms', 'mlp', 'tmp', 'llc', 'mph', 'cnn', 'tbs', 'sxc', 'npr', 'nbc', 'sbs', 'ctc', 'pmc', 'hms', 'lng', 'bfr', 'twc', 'cmv', 'csm', 'ssm', 'sdg', 'plc', 'ssb', 'krl', 'rpk', 'sts', 'cdp', 'wsj', 'www', 'msc', 'gdr', 'pdf', 'bgm', 'mrs', 'crt', 'ltd', 'pvc', 'nsw', 'tss', 'gdp', 'chs', 'csp', 'rss', 'ncl', 'rsc', 'mdm', 'qld', 'bbc', 'nsc', 'cpt', 'vss', 'ccl', 'cdc', 'gps', 'hdl'] 



Word For: Word-Length 3, and vowel number 3:
...
words with 3 vowels -> 
['iii', 'eui', 'eau', 'you', 'ooo', 'eye'] 



Word For: Word-Length 4, and vowel number 0:
~small group size, not words
words with 0 vowels -> 
['cssc', 'xxxv', 'jdmm', 'ssbn', 'hmcs', 'cctv', 'gwlb', 'wttc', 'gmbh', 'jhbs', 'html', 'rsnr', 'ssgn', 'hmhs', 'lgbt', 'sdgs', 'jwsr', 'mbts', 'nmrc', 'wkmg', 'lccn', 'bldg', 'dcts', 'cnbc'] 



Word For: Word-Length 5, and vowel number 0:
can be ignored
words with 0 vowels -> 
['https', 'hswms', 'chpts', 'jmsdf', 'nsmrl'] 



Word For: Word-Length 5, and vowel number 4:
can be ignored
words with 4 vowels -> 
['baiae', 'audio', 'aquae', 'yahoo', 'easie', 'amaya', 'ukiyo'] 



Word For: Word-Length 7, and vowel number 1:
include: small but real, edge case
words with 1 vowels -> 
['prompts', 'francks', 'cbsnews', 'stretch', 'schmuck', 'strands', 'frenchs', 'strings', 'blights', 'lengths', 'flights', 'thrusts', 'srpskog', 'schultz', 'schmidt'] 



Word For: Word-Length 7, and vowel number 5:
note: small group BUT real common words
words with 5 vowels -> 
['uruguay', 'oceania', 'nouveau', 'mayreau', 'eurasia', 'akiyama', 'ushuaia', 'europie', 'queneau', 'youtube'] 



Word For: Word-Length 9, and vowel number 6:
can be ignored
words with 6 vowels -> 
['audacious', 'auxiliary', 'uruguayan', 'aquitania', 'aguesseau', 'louisiana'] 



Word For: Word-Length 10, and vowel number 2:
include
words with 2 vowels -> 
['swampscott', 'nightclubs', 'withstands', 'strindberg', 'nighthawks', 'schnitzler', 'cartwright', 'schnorchel', 'hochschild', 'strickland', 'stretchers', 'shipwrecks', 'strictness', 'transports', 'strengthen', 'gottschalk', 'schjeldahl', 'frechtling', 'brunswicks', 'bandwidths', 'pittsburgh', 'transcript', 'splashdown', 'struggling', 'highlights'] 


Note: Over len ~12 words are few, safe rule: include any


Word For: Word-Length 12, and vowel number 7:
note: small group BUT real common words
words with 7 vowels -> 
['epidemiology', 'inequalities', 'inauguration', 'royalsociety', 'idealization', 'availability', 'aeronautical', 'evolutionary'] 



Word For: Word-Length 13, and vowel number 3:
include
words with 3 vowels -> 
['chartplotters', 'strengthening', 'transgressors', 'craftsmanship', 'handschriften'] 



Word For: Word-Length 16, and vowel number 5:
?
words with 5 vowels -> 
['selbstzeugnissen'] 


"""
