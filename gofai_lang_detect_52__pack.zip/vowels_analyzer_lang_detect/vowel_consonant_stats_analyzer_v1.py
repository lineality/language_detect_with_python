
"""
# Vowel-Length Ratio Text Analyzer Documentation

## Purpose
This analyzer performs statistical analysis of text to establish baseline patterns of natural language, specifically focusing on word length distribution and vowel ratios. It can be used as part of a language detection system to identify non-natural or manipulated text.

## Core Functionality
The analyzer categorizes words into four length-based bins and calculates vowel-to-length ratios:

### Word Length Categories
- Very Short (1-3 characters)
- Short (4-6 characters)
- Medium (7-9 characters)
- Long (10+ characters)

### Measurements Per Category
- Word count
- Average vowel ratio
- Vowel ratio range
- Average length
- Example words

### Statistical Baselines (from Wikipedia corpus analysis, n=25,604 words)
1. **Length Distribution:**
   - Peak frequency: 3 characters (4,186 words)
   - Secondary peak: 4 characters (3,445 words)
   - Words >15 characters: <0.4% of total
   - Average word length: 5.39 characters

2. **Vowel Ratios:**
   - Very Short: 0.450 (range: 0.000-1.000)
   - Short: 0.384 (range: 0.000-1.000)
   - Medium: 0.404 (range: 0.143-0.750)
   - Long: 0.417 (range: 0.200-0.600)
   - Overall average: 0.414

3. **Category Distribution:**
   - Very Short: 33.2%
   - Short: 32.9%
   - Medium: 24.2%
   - Long: 9.6%

## Implementation
The analyzer processes input text through:
1. Word tokenization
2. Length-based categorization
3. Vowel ratio calculation
4. Statistical analysis per category
5. Overall distribution analysis

## Output
Returns a structured dictionary containing all measurements and statistics, suitable for integration into larger language processing systems.

---e.g. ---

Vowel Ratio Analysis Results:
--------------------------------------------------

Very Short Words:
Definition: 1-3 characters
Count: 39764
Average vowel ratio: 0.435
Vowel ratio range: 0.000 - 1.000
Average length: 2.4
Examples: dc, mid, vol, had, sul

Short Words:
Definition: 4-6 characters
Count: 35179
Average vowel ratio: 0.384
Vowel ratio range: 0.000 - 1.000
Average length: 4.9
Examples: path, orton, colin, retake, fifth

Medium Words:
Definition: 7-9 characters
Count: 26554
Average vowel ratio: 0.400
Vowel ratio range: 0.125 - 0.750
Average length: 7.8
Examples: worried, severus, citoyen, appointed, parkinson

Long Words:
Definition: 10+ characters
Count: 11244
Average vowel ratio: 0.407
Vowel ratio range: 0.182 - 0.636
Average length: 11.3
Examples: revolutionary, deliberation, subliminal, pronouncements, emphasizing

Overall Statistics:
Total words: 112741
Average word length: 5.35
Average vowel ratio: 0.408

Word Length Distribution:
1 chars: 4133 words
2 chars: 16433 words
3 chars: 19198 words
4 chars: 12674 words
5 chars: 11729 words
6 chars: 10776 words
7 chars: 11246 words
8 chars: 8354 words
9 chars: 6954 words
10 chars: 4787 words
11 chars: 2495 words
12 chars: 1542 words
13 chars: 1695 words
14 chars: 439 words
15 chars: 138 words
16 chars: 72 words
17 chars: 35 words
18 chars: 14 words
19 chars: 6 words
20 chars: 6 words
21 chars: 5 words
23 chars: 1 words
25 chars: 1 words
26 chars: 2 words
29 chars: 1 words
30 chars: 1 words
32 chars: 1 words
33 chars: 1 words
37 chars: 1 words
49 chars: 1 words



maybe:

WORD_LENGTH_DISTRIBUTION = {
    'very_short': (1,3),   # ~33% of words (8513/25604)
    'short':      (4,6),   # ~33% of words (8420/25604)
    'medium':     (7,9),   # ~24% of words (6204/25604)
    'long':       (10,21)  # ~10% of words (2467/25604)
}
2. Refined Vowel Ratio Parameters:
pythonCopyVOWEL_RATIO_BOUNDS = {
    'very_short': (0.45, 0.15),  # mean=0.450, allow ±0.15
    'short':      (0.38, 0.10),  # mean=0.384, allow ±0.10
    'medium':     (0.40, 0.10),  # mean=0.404, allow ±0.10
    'long':       (0.42, 0.10)   # mean=0.417, allow ±0.10
}
"""

def analyze_vowel_length_ratios(text: str) -> dict:
    """
    Analyzes word length and vowel ratio distributions in English text.
    
    Word Length Bins (based on corpus analysis*):
        - Very Short: 1-3 chars (a, an, the, in, of...)
        - Short: 4-6 chars (most common length in English)
        - Medium: 7-9 chars (typical complex words)
        - Long: 10+ chars (compound/technical terms)
    
    *Note: These bins are based on:
    - Average English word length ~5 chars
    - ~80% of English words are 4-8 chars
    - Function words cluster in very short bin
    - Technical/compound words cluster in long bin
    
    Vowel Ratio Expectations:
    - English averages ~40% vowels per word
    - Very short words: 30-60% vowels (high variance)
    - Typical words: 35-45% vowels
    - Long words: 35-50% vowels
    
    Args:
        text (str): Input text to analyze
        
    Returns:
        dict: Statistics including:
            - Word counts and distributions by length bin
            - Vowel ratio statistics per bin
            - Overall corpus statistics
    """
    import re
    from statistics import mean, stdev
    from collections import Counter
    
    # Include y/Y as vowels when they function as vowels
    # This is simplified - y/Y vowel detection could be more sophisticated
    VOWELS = set('aeiouyAEIOUY')
    
    def get_vowel_ratio(word: str) -> float:
        """
        Calculate ratio of vowels to word length.
        Returns 0.0 for empty strings.
        """
        if not word:
            return 0.0
        vowel_count = sum(1 for c in word if c in VOWELS)
        return vowel_count / len(word)

    # Initialize bins with more natural breakpoints
    very_short_words = []  # 1-3 chars
    short_words = []       # 4-6 chars
    medium_words = []      # 7-9 chars
    long_words = []        # 10+ chars
    
    # Clean and tokenize
    # More thorough cleaning than previous version
    words = re.findall(r'\b[a-zA-Z]+\b', text.lower())
    
    # Sort words into bins and calculate ratios
    for word in words:
        length = len(word)
        ratio = get_vowel_ratio(word)
        
        if length <= 3:
            very_short_words.append((word, ratio, length))
        elif length <= 6:
            short_words.append((word, ratio, length))
        elif length <= 9:
            medium_words.append((word, ratio, length))
        else:
            long_words.append((word, ratio, length))

    def bin_stats(word_data: list) -> dict:
        """
        Calculate detailed statistics for a bin of (word, ratio, length) tuples.
        Includes length statistics and frequency analysis.
        """
        if not word_data:
            return {
                'count': 0,
                'avg_vowel_ratio': 0,
                'min_ratio': 0,
                'max_ratio': 0,
                'std_dev_ratio': 0,
                'avg_length': 0,
                'std_dev_length': 0,
                'most_common': [],
                'examples': []
            }
            
        ratios = [r for _, r, _ in word_data]
        lengths = [l for _, _, l in word_data]
        words = [w for w, _, _ in word_data]
        
        # Get frequency distribution
        word_freq = Counter(words).most_common(5)
        
        return {
            'count': len(word_data),
            'avg_vowel_ratio': mean(ratios),
            'min_ratio': min(ratios),
            'max_ratio': max(ratios),
            'std_dev_ratio': stdev(ratios) if len(ratios) > 1 else 0,
            'avg_length': mean(lengths),
            'std_dev_length': stdev(lengths) if len(lengths) > 1 else 0,
            'most_common': word_freq,
            'examples': list(set(words))[:5]  # First 5 unique examples
        }

    # Compile results with bin definitions
    results = {
        'very_short_words': {
            'definition': '1-3 characters',
            'stats': bin_stats(very_short_words)
        },
        'short_words': {
            'definition': '4-6 characters',
            'stats': bin_stats(short_words)
        },
        'medium_words': {
            'definition': '7-9 characters',
            'stats': bin_stats(medium_words)
        },
        'long_words': {
            'definition': '10+ characters',
            'stats': bin_stats(long_words)
        },
        'overall': {
            'total_words': len(words),
            'avg_word_length': mean(len(w) for w in words) if words else 0,
            'avg_vowel_ratio': mean(get_vowel_ratio(w) for w in words) if words else 0,
            'length_distribution': Counter(len(w) for w in words)
        }
    }
    
    return results

# Example usage with analysis
if __name__ == "__main__":

    # Get Text from file or default to default_tester_text

    default_tester_text = """
    The quick brown fox jumps over the lazy dog.
    This is a comprehensive test of the vowel ratio
    analysis system with some longer words like
    extraordinary and antidisestablishmentarianism
    mixed with short ones like cat and dog.
    """

    try:
        with open('text_doc.txt', 'r', encoding='utf-8') as file:
            test_text = file.read()
            if not test_text.strip():
                raise ValueError("File is empty")
    except FileNotFoundError:
        print("Error: 'text_doc.txt' not found in current directory")
        test_text = default_tester_text
    except ValueError as e:
        print(f"Error: {e}")
        test_text = default_tester_text
    except Exception as e:
        print(f"Unexpected error reading file: {str(e)}")
        test_text = default_tester_text

    stats = analyze_vowel_length_ratios(test_text)
    
    print("\nVowel Ratio Analysis Results:")
    print("-" * 50)
    
    for bin_name, bin_data in stats.items():
        if bin_name != 'overall':
            print(f"\n{bin_name.replace('_', ' ').title()}:")
            print(f"Definition: {bin_data['definition']}")
            bin_stats = bin_data['stats']
            print(f"Count: {bin_stats['count']}")
            print(f"Average vowel ratio: {bin_stats['avg_vowel_ratio']:.3f}")
            print(f"Vowel ratio range: {bin_stats['min_ratio']:.3f} - {bin_stats['max_ratio']:.3f}")
            print(f"Average length: {bin_stats['avg_length']:.1f}")
            print(f"Examples: {', '.join(bin_stats['examples'])}")
    
    print("\nOverall Statistics:")
    print(f"Total words: {stats['overall']['total_words']}")
    print(f"Average word length: {stats['overall']['avg_word_length']:.2f}")
    print(f"Average vowel ratio: {stats['overall']['avg_vowel_ratio']:.3f}")
    
    # Print length distribution
    print("\nWord Length Distribution:")
    for length, count in sorted(stats['overall']['length_distribution'].items()):
        print(f"{length} chars: {count} words")
