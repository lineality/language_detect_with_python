
from gofai_language_detect import lang_detect_word_sentence_counter

test_it = """
    
"""


test_it = """

"""

test_it = """

"""


test_it = """

"""
result = lang_detect_word_sentence_counter(test_it)

print(result)
