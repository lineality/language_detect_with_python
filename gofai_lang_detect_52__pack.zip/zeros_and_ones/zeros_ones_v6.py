"""
zeros and ones lang_detect analyzer/archiver:
isoate and examine zero and one cases.


Requires pandas in python env

archive zero and archive 1:  iterate through a csv as a pandas df, and apply/run a function to examine strings in the 'A' column, if the result is zero or 1, the string from that column will be archived, appended to 'zeros_archive.txt' file or a 'ones_archive.txt' file


### Explanation:
1. **Function Definition**:
   - `examine_string(s)`: This function takes a string `s` and returns 0, 1, or `None` based on some logic. You should replace the placeholder logic with your actual logic for determining whether a string should be archived as 0 or 1.

2. **Loading the CSV**:
   - `pd.read_csv('your_file.csv')`: This line loads the CSV file into a pandas DataFrame. Replace `'your_file.csv'` with the path to your actual CSV file.

3. **Opening Archive Files**:
   - `with open('zeros_archive.txt', 'a') as zeros_file, open('ones_archive.txt', 'a') as ones_file`: This opens the archive files in append mode. If the files do not exist, they will be created.

4. **Iterating Through the DataFrame**:
   - `for index, row in df.iterrows()`: This loop iterates through each row in the DataFrame.
   - `string_value = row['A']`: This gets the value from the 'A' column for the current row.
   - `result = examine_string(string_value)`: This calls the `examine_string` function to determine the result.
   - `if result == 0`: If the result is 0, the string is appended to `zeros_archive.txt`.
   - `elif result == 1`: If the result is 1, the string is appended to `ones_archive.txt`.

### Best Practices:
- **Error Handling**: Add error handling to manage potential issues like file not found, permission errors, or invalid CSV formats.
- **Logging**: Consider adding logging to track the progress and any issues that occur during the archiving process.
- **Configuration**: Make the file paths and column names configurable to avoid hardcoding values.
"""

import os
import logging
from typing import Optional
import pandas as pd
from gofai_language_detect import lang_detect_word_sentence_counter
from datetime import datetime
import shutil

# Set the maximum number of entries per archive file
MAX_ENTRIES_PER_FILE = 1000

TARGET_TEXT_COLUMN = "BODY"
GROUP_ID = "CONVERSATION_ID"

REQUIRED_COLUMNS_LIST = [
    TARGET_TEXT_COLUMN,
    GROUP_ID,
]

# Define the list of strings to remove
LIST_OF_STRINGS_TO_REMOVE = [

]
    


# Define a function to remove substrings from a string
def remove_trash_substrings_from_string(input_text):
    """
    removes known filler-text, often whole sentences,
    from whole-document strings.
    """

    new_text = input_text

    for item_to_filter_out in LIST_OF_STRINGS_TO_REMOVE:
        new_text = new_text.replace(item_to_filter_out, "")

    return new_text


#####################
# readable_timestamp
#####################
raw_datetime = datetime.now()
readable_timestamp = raw_datetime.strftime("%Y_%m_%d__%H_%M_%S_%f")

use_this_file = input("Enter path...\n")


# Extract the file name
file_name = os.path.basename(use_this_file)

# Remove the .csv suffix
file_name_without_suffix = os.path.splitext(file_name)[0]


# Load the CSV file into a pandas DataFrame
# df = pd.read_csv('your_file.csv')
# Consider using specific usecols when reading CSV:
df = pd.read_csv(use_this_file, usecols=REQUIRED_COLUMNS_LIST)

##################################
# Convert column to be all-string
##################################
df[TARGET_TEXT_COLUMN] = df[TARGET_TEXT_COLUMN].astype(str)

#############
# Clean Text
#############
# Apply the function to the `text` column
df[TARGET_TEXT_COLUMN] = df[TARGET_TEXT_COLUMN].apply(
    lambda x: remove_trash_substrings_from_string(x)
)

##############################
# Find & Archive Zeros & Ones
##############################
no_exception = False
OUTPUT_DIRECTORY = f"ones_and_zeros_data/{file_name_without_suffix}_{readable_timestamp}"

# Ensure the directory exists
if not os.path.exists(OUTPUT_DIRECTORY):
    os.makedirs(OUTPUT_DIRECTORY)
    

def process_and_split_files(df, max_entries_per_file=MAX_ENTRIES_PER_FILE):
    """
    Phase 1: Create two files (ones and zeros)
    Phase 2: Split these files into smaller files based on max_entries
    """
    # Ensure the directory exists
    os.makedirs(OUTPUT_DIRECTORY, exist_ok=True)

    zeros_counter = 0
    ones_counter = 0
    twos_threes_counter = 0
    total_counter = 0
    
    # Phase 1: Create initial files
    zeros_path = f"{OUTPUT_DIRECTORY}/zeros_archive.txt"
    ones_path = f"{OUTPUT_DIRECTORY}/ones_archive.txt"
    twos_threes_path = f"{OUTPUT_DIRECTORY}/twos_threes_archive.txt"

    try:
        # Create the initial two files
        with open(zeros_path, 'w') as zeros_file, open(ones_path, 'w') as ones_file, open(twos_threes_path, 'w') as twos_threes_file:
            # Process all entries
            for index, row in df.iterrows():
                string_value = row["BODY"]
                result = lang_detect_word_sentence_counter(string_value)[1]
                archive_item = f'"""\n{string_value}\n""",\n\n\n'
                
                total_counter += 1
                
                if result == 0:
                    zeros_file.write(archive_item)
                    zeros_counter += 1

                elif result == 1:
                    ones_file.write(archive_item)
                    ones_counter += 1
                    
                elif (result == 2) or (result == 3):
                    twos_threes_file.write(archive_item)
                    twos_threes_counter += 1


        # Phase 2: Split files if they're too large
        def split_large_file(filepath, base_name, max_entries):
            if not os.path.exists(filepath):
                return

            with open(filepath, 'r') as source_file:
                content = source_file.read()
                entries = content.split('"""')[1:]  # Split on """ and remove first empty element

                # Calculate number of complete entries
                num_entries = len(entries) // 2  # Because split creates two parts per entry

                if num_entries <= max_entries:
                    # Rename original file to _1
                    new_name = f"{os.path.splitext(filepath)[0]}_1.txt"
                    shutil.move(filepath, new_name)
                    return

                # Split into multiple files
                for i in range(0, num_entries, max_entries):
                    file_number = (i // max_entries) + 1
                    new_filepath = f"{os.path.splitext(filepath)[0]}_{file_number}.txt"

                    with open(new_filepath, 'w') as target_file:
                        start_idx = i * 2
                        end_idx = min((i + max_entries) * 2, len(entries))
                        entries_chunk = entries[start_idx:end_idx]
                        for entry in entries_chunk:
                            target_file.write(f'"""{entry}')

                # Remove original file
                if os.path.exists(filepath):
                    os.remove(filepath)


        # Split both files
        split_large_file(zeros_path, "zeros_archive", max_entries_per_file)
        split_large_file(ones_path, "ones_archive", max_entries_per_file)
        split_large_file(twos_threes_path, "twos_threes_archive", max_entries_per_file)

        summary_blurb = f"""
            zeros_counter = {zeros_counter}
            ones_counter  = {ones_counter}
            2's 3's count = {twos_threes_counter}
           _________________________________   
            total_counter = {total_counter}            

            percent of rows (not conversations) are zero = {(zeros_counter / total_counter) * 100 } %
        """

        print(summary_blurb)

        return True

    except Exception as e:
        print(f"process_and_split_files, Error occurred: {str(e)}")
        return False


######
# Run
######
no_exception = process_and_split_files(df, max_entries_per_file=MAX_ENTRIES_PER_FILE)

if no_exception is True:
    print("\nOK! Archiving complete.\n")
else:
    print("\nSomething terrible happened... I'm so sorry!\n")
