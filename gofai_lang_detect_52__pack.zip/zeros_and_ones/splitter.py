SPLIT_SENTENCES_ON_N_WORDS = 30

MAX_WORDS_PER_SENTENCE = 100

def split_over_max_sentence_strings(input_sentences_list):
    """
    Splits each sentence in the list into smaller segments if it exceeds the minimum number of words per sentence.

    Args:
    input_sentences_list (list of str): List of sentences to be processed.
    MAX_WORDS_PER_SENTENCE (int): Maximum number of words allowed per sentence segment.

    Returns:
    list of str: List of sentences with each sentence split into smaller segments if necessary.
    
    Uses:
    SPLIT_SENTENCES_ON_N_WORDS = int
    MAX_WORDS_PER_SENTENCE = int
    """
    try:
        split_list = []
    
        for this_sentence in input_sentences_list:
            words = this_sentence.split()
            num_words = len(words)
    
            if num_words <= MAX_WORDS_PER_SENTENCE:
                split_list.append(this_sentence)
            else:
                # Split the sentence into smaller segments
                for i in range(0, num_words, SPLIT_SENTENCES_ON_N_WORDS):
                    segment = ' '.join(words[i:i + SPLIT_SENTENCES_ON_N_WORDS])
                    split_list.append(segment)
    
        return split_list
    except Exception as e:
        print(str(e))
        return(input_sentences_list)


SPLIT_SENTENCES_ON_N_WORDS = 30
MAX_WORDS_PER_SENTENCE = 100

def split_over_max_sentencewordlists(input_sentences_list):
    """
    Splits each sentence in the list into smaller segments if it exceeds the maximum number of words per sentence.

    Args:
    input_sentences_list (list of list of str): List of sentences where each sentence is a list of words.
    MAX_WORDS_PER_SENTENCE (int): Maximum number of words allowed per sentence segment.

    Returns:
    list of list of str: List of sentences with each sentence split into smaller segments if necessary.

    Uses:
    SPLIT_SENTENCES_ON_N_WORDS (int): Number of words to split each sentence into smaller segments.
    MAX_WORDS_PER_SENTENCE (int): Maximum number of words allowed per sentence segment.
    """
    try:
        split_list = []

        for this_sentence in input_sentences_list:
            num_words = len(this_sentence)

            if num_words <= MAX_WORDS_PER_SENTENCE:
                split_list.append(this_sentence)
            else:
                # Split the sentence into smaller segments
                for i in range(0, num_words, SPLIT_SENTENCES_ON_N_WORDS):
                    segment = this_sentence[i:i + SPLIT_SENTENCES_ON_N_WORDS]
                    split_list.append(segment)

        return split_list
    except Exception as e:
        print(str(e))
        return input_sentences_list

# Example usage:
input_sentences = [["cat", "eats"], ["see", "spot", "run"]]
output_sentences = split_over_max_sentencewordlists(input_sentences)
print(output_sentences)


def split_over_max_onesentence_wordlist(input_sentence_wordlist):
    """
    Splits each sentence in the list into smaller segments if it exceeds the maximum number of words per sentence.

    Args:
    input_sentence_wordlist (list of list of str): List of sentences where each sentence is a list of words.
    MAX_WORDS_PER_SENTENCE (int): Maximum number of words allowed per sentence segment.

    Returns:
    list of list of str: List of sentences with each sentence split into smaller segments if necessary.

    Uses:
    SPLIT_SENTENCES_ON_N_WORDS (int): Number of words to split each sentence into smaller segments.
    MAX_WORDS_PER_SENTENCE (int): Maximum number of words allowed per sentence segment.
    """
    try:
        split_list = []

        num_words = len(input_sentence_wordlist)

        if num_words <= MAX_WORDS_PER_SENTENCE:
            split_list.append(input_sentence_wordlist)
        else:
            # Split the sentence into smaller segments
            for i in range(0, num_words, SPLIT_SENTENCES_ON_N_WORDS):
                segment = input_sentence_wordlist[i:i + SPLIT_SENTENCES_ON_N_WORDS]
                split_list.append(segment)

        return split_list
    except Exception as e:
        print(str(e))
        return input_sentence_wordlist

# Example usage
if __name__ == "__main__":
    # Input list of strings
    input_sentences = [
        """ """
    ]
    
    
    input_sentences = []
    

    if isinstance(input_sentences[0], str):
    
        # Split long sentences
        result = split_over_max_sentence_strings(input_sentences)
    
        # Print the result
        for sentence in result:
            print(sentence)
            print('\n')

    elif isinstance(input_sentences[0], list):
        
        # Split long sentences
        result = split_over_max_sentencewordlists(input_sentences)
    
        # Print the result
        for sentence in result:
            print(sentence)
            print('\n')

if isinstance(input_sentences[0], list):
    for i in input_sentences:
        print(split_over_max_onesentence_wordlist(input_sentences))
        
        
raw_sent = """

"""

split_sent = raw_sent.split()

print(split_over_max_onesentence_wordlist(split_sent))
