import string
from collections import defaultdict
import statistics

# List of stop words
NLTK_STOPWORDS = [
    "i", "me", "my", "myself", "we", "our", "ours", "ourselves", "you", "your", "yours", "yourself",
    "yourselves", "he", "him", "his", "himself", "she", "her", "hers", "herself", "it", "its",
    "itself", "they", "them", "their", "theirs", "themselves", "what", "which", "who", "whom",
    "this", "that", "these", "those", "am", "is", "are", "was", "were", "be", "been", "being",
    "have", "has", "had", "having", "do", "does", "did", "doing", "a", "an", "the", "and", "but",
    "if", "or", "because", "as", "until", "while", "of", "at", "by", "for", "with", "about",
    "against", "between", "into", "through", "during", "before", "after", "above", "below", "to",
    "from", "up", "down", "in", "out", "on", "off", "over", "under", "again", "further", "then",
    "once", "here", "there", "when", "where", "why", "how", "all", "any", "both", "each", "few",
    "more", "most", "other", "some", "such", "no", "nor", "not", "only", "own", "same", "so",
    "than", "too", "very", "s", "t", "can", "will", "just", "don", "should", "now"
]

# Function to count stop words in a sentence
def count_stop_words(sentence):
    word_count = len(sentence.split())
    stop_word_count = len([word for word in sentence.split() if word in NLTK_STOPWORDS])
    return word_count, stop_word_count

# Read sentences from file
with open('clean_sentences_list.txt', 'r') as file:
    sentences = file.readlines()

# Calculate word length and character length for each sentence
word_lengths = []
char_lengths = []
sentence_data = defaultdict(list)

# Process each sentence
for sentence in sentences:
    sentence = sentence.strip().lower()
    sentence = sentence.translate(str.maketrans('', '', string.punctuation))
    word_count, stop_word_count = count_stop_words(sentence)
    word_lengths.append(word_count)
    char_lengths.append(len(sentence))
    sentence_data[word_count].append(stop_word_count)

# Calculate mean, median, and mode for word and character lengths
mean_word_length = statistics.mean(word_lengths)
median_word_length = statistics.median(word_lengths)
mode_word_length = statistics.mode(word_lengths)

mean_char_length = statistics.mean(char_lengths)
median_char_length = statistics.median(char_lengths)
mode_char_length = statistics.mode(char_lengths)

# Calculate quartiles for word and character lengths
q25_word_length = statistics.quantiles(word_lengths, n=4)[0]
q75_word_length = statistics.quantiles(word_lengths, n=4)[2]

q25_char_length = statistics.quantiles(char_lengths, n=4)[0]
q75_char_length = statistics.quantiles(char_lengths, n=4)[2]

# Print statistics for word and character lengths
print(f'Mean words: {mean_word_length}')
print(f'Median words: {median_word_length}')
print(f'Mode words: {mode_word_length}')
print(f'25th Percentile words: {q25_word_length}')
print(f'75th Percentile words: {q75_word_length}')

print(f'Mean characters: {mean_char_length}')
print(f'Median characters: {median_char_length}')
print(f'Mode characters: {mode_char_length}')
print(f'25th Percentile characters: {q25_char_length}')
print(f'75th Percentile characters: {q75_char_length}')

# Sort sentence lengths
sorted_lengths = sorted(sentence_data.keys())

# Calculate statistics for each sentence length
for length in sorted_lengths:
    stop_word_counts = sentence_data[length]
    ratio = [count / length for count in stop_word_counts]
    print(f'Sentence length: {length} words')
    print(f'  Average ratio: {statistics.mean(ratio)}')
    print(f'  Median ratio: {statistics.median(ratio)}')
    if len(ratio) > 1:
        print(f'  Lower quartile ratio: {statistics.quantiles(ratio, n=4)[0]}')
        print(f'  Upper quartile ratio: {statistics.quantiles(ratio, n=4)[2]}')
    else:
        print('  Not enough data points to calculate quartiles.')

