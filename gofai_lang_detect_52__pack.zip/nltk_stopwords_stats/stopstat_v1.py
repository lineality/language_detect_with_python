
import string
from collections import Counter, defaultdict
import statistics

NLTK_STOPWORDS = [
    "i",
    "me",
    "my",
    "myself",
    "we",
    "our",
    "ours",
    "ourselves",
    "you",
    "your",
    "yours",
    "yourself",
    "yourselves",
    "he",
    "him",
    "his",
    "himself",
    "she",
    "her",
    "hers",
    "herself",
    "it",
    "its",
    "itself",
    "they",
    "them",
    "their",
    "theirs",
    "themselves",
    "what",
    "which",
    "who",
    "whom",
    "this",
    "that",
    "these",
    "those",
    "am",
    "is",
    "are",
    "was",
    "were",
    "be",
    "been",
    "being",
    "have",
    "has",
    "had",
    "having",
    "do",
    "does",
    "did",
    "doing",
    "a",
    "an",
    "the",
    "and",
    "but",
    "if",
    "or",
    "because",
    "as",
    "until",
    "while",
    "of",
    "at",
    "by",
    "for",
    "with",
    "about",
    "against",
    "between",
    "into",
    "through",
    "during",
    "before",
    "after",
    "above",
    "below",
    "to",
    "from",
    "up",
    "down",
    "in",
    "out",
    "on",
    "off",
    "over",
    "under",
    "again",
    "further",
    "then",
    "once",
    "here",
    "there",
    "when",
    "where",
    "why",
    "how",
    "all",
    "any",
    "both",
    "each",
    "few",
    "more",
    "most",
    "other",
    "some",
    "such",
    "no",
    "nor",
    "not",
    "only",
    "own",
    "same",
    "so",
    "than",
    "too",
    "very",
    "s",
    "t",
    "can",
    "will",
    "just",
    "don",
    "should",
    "now",
    ]

# Function to count stop words in a sentence
def count_stop_words(sentence):
    word_count = len(sentence.split())
    stop_word_count = len([word for word in sentence.split() if word in NLTK_STOPWORDS])
    return word_count, stop_word_count

# Read sentences from file
with open('clean_sentences_list.txt', 'r') as file:
    sentences = file.readlines()

# Initialize data structure to hold sentence lengths and stop word counts
sentence_data = defaultdict(list)

# Process each sentence
for sentence in sentences:
    sentence = sentence.strip().lower()
    sentence = sentence.translate(str.maketrans('', '', string.punctuation))
    word_count, stop_word_count = count_stop_words(sentence)
    sentence_data[word_count].append(stop_word_count)

# Calculate statistics for each sentence length
for length, stop_word_counts in sentence_data.items():
    ratio = [count / length for count in stop_word_counts]
    print(f'Sentence length: {length} words')
    print(f'  Average ratio: {statistics.mean(ratio)}')
    print(f'  Median ratio: {statistics.median(ratio)}')
    if len(ratio) > 1:
        print(f'  Lower quartile ratio: {statistics.quantiles(ratio)[0]}')
        print(f'  Upper quartile ratio: {statistics.quantiles(ratio)[2]}')
    else:
        print('  Not enough data points to calculate quartiles.')
