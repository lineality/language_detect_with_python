import unittest
from gofai_language_detect import lang_detect_word_sentence_counter


############################
# Example usage and testing
############################

# test_text = """
# Hello world! This is a test sentence.
# It has some numbers like 42 and ABC123.
# This isn't a very l0ng text, but it works well-enough.
# Some invalid things like @@@ or ### should be ignored.
# """

# word_count, sentence_count = lang_detect_word_sentence_counter(test_text)
# print(f"Valid words found: {word_count}")
# print(f"Complete sentences identified: {sentence_count}")

test_cases = [
    "Cat often like the mangos. Meatballs are sometimes heard giggling. Fish are our friends, always."
    "Dr. Jones, Prof. Smith and Mrs. Brown attended the meeting on Downing St. Inc.",
    "This is sentence one. This is sentence two! What about three?",
    "This is sentence one. This is sentence two. Here is!",  # mix
    "Mr. Smith went to Washington. He had a great time!",
    "Short. Too short. This is a proper sentence.",
    "This sentence is incomplete because",
    "please reply to my request about weather, tom", # this is valid

    # not valid
    "fraud@crypto is the B!!!est slimball.",
    "First sentence. second sentence.", # capitalization is NOT a criteria, length is
    "BUY SPAM BUY SPAM!",  # not valid
    "this sent in error",  # not valid
]

##############
# manual test
##############
for this_text in test_cases:
    words, sentences = lang_detect_word_sentence_counter(this_text)
    print(f"this_text -> {this_text}")
    print(f"Words -> {words}, Sentences -> {sentences}\n")


# empty/incomplete emails
invalid_incomplete_test_cases_2 = [
"""
"buy $$$"
""",
"""
    "BUY SPAM BUY SPAM!",  # not valid
""",
]

# short/borderline examples
valid_short_test_cases_4 = [
"""
He had a great time there.
""",
"""
This is sentence one.
""",
"""
This is really a sentence.
""",
]

valid_sample_cases = [
    "Mr. Smith went to Washington. He had a great time!",
    "This is sentence one. This is sentence two! What about three?",
    "Short. Too short. This is a proper sentence.",
    "Dr. Jones, Prof. Smith and Mrs. Brown attended the meeting on Downing St. Inc.",
    "This sentence is not incomplete.",
]

# # Valid Emails
valid_borderline_test_cases_3 = [
"""
This is a proper sentence.
""",
"""
Short. Too short. This is a proper sentence.
""",
]

# probably_invalid edge cases
edge_case_probably_invalid = [
"""
buy $$$
""",

"""
SPAM SPAM!
""",
"fraud@crypto is the B!!!est slimball.",
]


###########
# Unittest
###########
"""
NOTE: In Python's unittest framework,
test methods must start with the word "test_"
to be automatically discovered and executed by the test runner

use:
    python3 -m unittest gofai_language_detect.py
"""

# short_test_cases_4
class ValidShortCasesTestLanguageDetection(unittest.TestCase):
    def test_short_valid(self):
        for test_case in valid_short_test_cases_4:
            with self.subTest(test_case=test_case):
                result = lang_detect_word_sentence_counter(test_case)
                self.assertGreater(result[1], 0)

class EmptyInvalidTestLanguageDetection(unittest.TestCase):
    def test_empty_invalid(self):
        for test_case in invalid_incomplete_test_cases_2:
            with self.subTest(test_case=test_case):
                result = lang_detect_word_sentence_counter(test_case)
                self.assertEqual(result[1], 0)


class EdgeCaseInvalidTestLanguageDetection(unittest.TestCase):
    def test_edgecase_empty_invalid(self):
        for test_case in edge_case_probably_invalid:
            with self.subTest(test_case=test_case):
                result = lang_detect_word_sentence_counter(test_case)
                self.assertEqual(result[1], 0)

class ValidBorderlineTestLanguageDetection(unittest.TestCase):
    def test_valid_borderline(self):
        for test_case in valid_borderline_test_cases_3:
            with self.subTest(test_case=test_case):
                result = lang_detect_word_sentence_counter(test_case)
                self.assertGreater(result[1], 0)

class ValidSampleTestLanguageDetection(unittest.TestCase):
    def test_valid_samples(self):
        for test_case in valid_sample_cases:
            with self.subTest(test_case=test_case):
                result = lang_detect_word_sentence_counter(test_case)
                self.assertGreater(result[1], 0)

if __name__ == '__main__':
    unittest.main()
